-- commands_db.sql

-- Tabella per registrare i comandi usati
CREATE TABLE IF NOT EXISTS command_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    command TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabella per i promemoria
CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    time INTEGER,
    reminder TEXT
);
